package com.example.myapplication

import android.graphics.Bitmap

data class ImageFromInterface(
    val image:Bitmap
)
